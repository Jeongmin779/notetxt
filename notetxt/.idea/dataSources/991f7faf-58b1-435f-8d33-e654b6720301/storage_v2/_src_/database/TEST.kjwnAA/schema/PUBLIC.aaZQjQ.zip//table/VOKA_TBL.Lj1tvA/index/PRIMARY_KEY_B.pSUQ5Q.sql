create unique index PRIMARY_KEY_B
    on VOKA_TBL (VOKA_NO);

