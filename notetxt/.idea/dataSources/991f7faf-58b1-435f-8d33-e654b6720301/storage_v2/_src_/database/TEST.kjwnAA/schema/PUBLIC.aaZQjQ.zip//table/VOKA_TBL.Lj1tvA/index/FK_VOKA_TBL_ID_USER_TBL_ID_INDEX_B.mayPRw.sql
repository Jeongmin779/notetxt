create index FK_VOKA_TBL_ID_USER_TBL_ID_INDEX_B
    on VOKA_TBL (ID);

