create unique index PRIMARY_KEY_A
    on CATEGORY_TBL (CATE_NO);

