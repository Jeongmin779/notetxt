create unique index PRIMARY_KEY_3
    on WORD_TBL (VOKA_NO, WORD_NO);

