create unique index PRIMARY_KEY_9
    on REPORT_TBL (REPORT_NO, ID, VOKA_NO);

